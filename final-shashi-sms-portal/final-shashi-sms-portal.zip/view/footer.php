<footer>
<div class="container">
			<!-- 	<div class="row"> -->
					<div class="col-md-6 col-sm-6 cont">
						<div class="one">
							<h2>About Sms Portal</h2><hr/>
							We have changed the way people text, connect with friends & family. From sending the coolest sms greetings, to scheduling sms when you're on the go, to grabbing mobile recharges for free, all this can be done using our services. 
						</div>
					</div>
					<div class="col-md-6 col-sm-6 cont">
						<div class="one">
							<h2>Send free sms </h2>
							<hr>
							We deliver your messages to all the mobile operators and networks for FREE<br>
								Never miss a birthday, or any important occasion, just schedule SMS for future delivery, absolutely free<br>
								You can also make Group SMS to many friends in one go 
						</div>
					</div>
				<!-- </div> -->
			</div>
	</footer>	
<!-- /////////////////////////////////////////// Start Footer part from here //////////////////////////////////////////////// -->
		<div class="footer text-center">
			<div class="col-md-12 col-sm-8 footer-text">
				Copyright © 2016 SMS portal | Full project by Shashikant Maurya
				<p>This template design by Shashikant Maurya</p>
			</div>
		</div>
</div>
	<script src="../assets/js/jquery.js"></script>
	<script src="../assets/js/project.js"></script>

	</body>
</html>