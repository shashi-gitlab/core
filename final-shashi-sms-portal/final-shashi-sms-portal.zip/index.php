<script>
	window.location.href="view/index.php";
</script>