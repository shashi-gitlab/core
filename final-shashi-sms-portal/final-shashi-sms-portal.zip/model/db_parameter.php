<?php
	interface db_parameter{
		const HOST="localhost";
		const USER="root";
		const PASS="";
		const DATABASE="sms-portal";
	}

?>