<?php
	require_once"../model/db_project.php";
?>

<!DOCTYPE html>
<html>
	<head>
		<title>SMS PORTAL</title>
		<link rel="icon" href="../assets/images/icon.png">
		<link rel="stylesheet" type="text/css" href="../assets/css/bootstrap.min.css">
		<link rel="stylesheet" type="text/css" href="../assets/css/font-awesome.min.css">
		<!-- <link rel="stylesheet" type="text/css" href="../assets/css/responsive-stylesheet.css"> -->

		<link rel="stylesheet" type="text/css" href="../assets/css/style.css">

	</head>
	
	<body>
		
		<div class="header">

			<div class="container header-container">
				<div class="row">
					<div class="col-md-4 text-center">
						<img src="../assets/images/sms.png" style="height:100px;">
					</div>
					<div class="col-md-8 ">
						<div class="menu">
							<p>SmsPortal is one of biggest portals, which allows you to send Free Sms to almost anywhere in the world. It offers several intuitive features like Free Sms.</p>
						</div>
					</div>
				</div>
			</div>
		</div>
		<!-- <div class="container welcome-box"> -->


